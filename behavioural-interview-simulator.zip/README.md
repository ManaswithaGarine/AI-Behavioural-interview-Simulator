# Behavioural Interview Simulator

Simple AI-driven behavioural interview simulator for practicing STAR-style answers. Built for a hackathon.

Run locally:

1. Install dependencies

```bash
npm install
```

2. Start server

```bash
npm start
```

3. Open http://localhost:3000 in your browser

Project structure:

- `server.js` - Express backend with modular agents (Question Manager, Answer Analyzer, STAR Scoring, Feedback Generator). Comments explain reasoning.
- `public/index.html` - Frontend UI (vanilla JS)
- `public/style.css` - Simple styling
- `public/script.js` - Frontend logic calling REST API

Notes:
- In-memory storage only, no DB.
- Rule-based agents with explainable heuristics—beginner-friendly code and comments.
