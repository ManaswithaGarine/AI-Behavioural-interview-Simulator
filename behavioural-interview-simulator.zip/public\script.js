// Behavioural Interview Simulator frontend logic
// - Fetches questions
// - Starts session
// - Sends answers to backend for STAR scoring
// - Shows feedback and final summary

let questions = [];
let sessionId = null;
let current = 0;

const startBtn = document.getElementById('startBtn');
const intro = document.getElementById('intro');
const questionPanel = document.getElementById('questionPanel');
const questionText = document.getElementById('questionText');
const answerInput = document.getElementById('answerInput');
const submitBtn = document.getElementById('submitBtn');
const feedback = document.getElementById('feedback');
const progress = document.getElementById('progress');
const summaryPanel = document.getElementById('summaryPanel');
const summaryContent = document.getElementById('summaryContent');
const restartBtn = document.getElementById('restartBtn');

async function loadQuestions() {
  const res = await fetch('/questions');
  const data = await res.json();
  questions = data.questions || [];
}

async function startSession() {
  const res = await fetch('/start', { method: 'POST' });
  const data = await res.json();
  sessionId = data.sessionId;
}

function showQuestion(idx) {
  const q = questions[idx];
  progress.textContent = `Question ${idx + 1} of ${questions.length}`;
  questionText.textContent = q;
  answerInput.value = '';
  feedback.innerHTML = '';
}

async function submitAnswer() {
  const answer = answerInput.value.trim();
  if (!answer) return alert('Please type an answer before submitting.');
  submitBtn.disabled = true;

  const payload = { sessionId, questionIndex: current, question: questions[current], answer };
  const res = await fetch('/answer', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
  const data = await res.json();

  // Show feedback for this question
  const star = data.entry.star;
  const suggestions = data.entry.suggestions;
  feedback.innerHTML = `<div><strong>STAR scores:</strong> Situation ${star.situation}, Task ${star.task}, Action ${star.action}, Result ${star.result} — <span class="starScore">${star.total}/8</span></div>`;
  if (suggestions && suggestions.length) {
    const ul = document.createElement('ul');
    suggestions.forEach(s => { const li = document.createElement('li'); li.textContent = s; ul.appendChild(li); });
    feedback.appendChild(ul);
  }

  // Move to next after a short delay
  setTimeout(() => {
    current += 1;
    if (current < questions.length) {
      showQuestion(current);
      submitBtn.disabled = false;
    } else {
      showSummary();
    }
  }, 900);
}

async function showSummary() {
  const res = await fetch(`/summary?sessionId=${sessionId}`);
  const data = await res.json();
  questionPanel.classList.add('hidden');
  summaryPanel.classList.remove('hidden');

  const pct = Math.round((data.totalScore / data.maxScore) * 100 || 0);
  let html = `<p><strong>Total:</strong> ${data.totalScore} / ${data.maxScore} (${pct}%)</p>`;
  data.perQuestion.forEach(p => {
    html += `<div class="summary-entry"><div><strong>Q${p.questionIndex + 1}:</strong> ${p.question}</div>`;
    html += `<div>STAR — S:${p.star.situation} T:${p.star.task} A:${p.star.action} R:${p.star.result} => <span class="starScore">${p.star.total}/8</span></div>`;
    if (p.suggestions && p.suggestions.length) {
      html += '<div><strong>Suggestions:</strong><ul>' + p.suggestions.map(s => `<li class="suggestion">${s}</li>`).join('') + '</ul></div>';
    }
    html += '</div>';
  });
  summaryContent.innerHTML = html;
}

startBtn.addEventListener('click', async () => {
  startBtn.disabled = true;
  await loadQuestions();
  await startSession();
  intro.classList.add('hidden');
  questionPanel.classList.remove('hidden');
  showQuestion(0);
});

submitBtn.addEventListener('click', submitAnswer);
restartBtn.addEventListener('click', () => location.reload());
